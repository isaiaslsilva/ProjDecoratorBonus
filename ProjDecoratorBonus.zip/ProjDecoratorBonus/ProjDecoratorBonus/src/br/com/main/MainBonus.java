package br.com.main;

import br.com.generico.BonusDecorator;
import br.com.modelo.Bonus5Gbinternet;


public class MainBonus {

	public static void main(String[] args) {
BonusDecorator bonustel = new BonusDecorator("Bonus Telefonia", 100, new Bonus5Gbinternet("Bonus Internet", 200));
bonustel.imprimir();
		

	}

}
