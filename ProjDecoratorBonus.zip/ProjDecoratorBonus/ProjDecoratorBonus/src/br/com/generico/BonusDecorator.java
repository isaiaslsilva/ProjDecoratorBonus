package br.com.generico;

import br.com.generico.Bonus;
public class BonusDecorator extends Bonus {

	private Bonus opcional;
	private String descricao;
	private double preco;
	
	public BonusDecorator (String descricao, double preco, Bonus opcional) {
		super(Bonus.getDescricao(), Bonus.getPreco());
		this.descricao = descricao;
		this.preco = preco;
	}
	
	public Bonus getOpcional() {
		return opcional;
	}

	public void setOpcional(Bonus opcional) {
		this.opcional = opcional;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public void imprimir() {
		System.out.println(super.getDescricao() +  " " + super.getPreco());
		System.out.println(getDescricao() + " " + getPreco());
	}

}
