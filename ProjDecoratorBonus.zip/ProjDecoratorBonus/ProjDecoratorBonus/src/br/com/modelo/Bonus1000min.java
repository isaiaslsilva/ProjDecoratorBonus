package br.com.modelo;

import br.com.generico.Bonus;
import br.com.generico.BonusDecorator;

public class Bonus1000min extends BonusDecorator {

	public Bonus1000min(String descricao, double preco, Bonus opcional) {
		super(descricao, preco, opcional);
	}

}
