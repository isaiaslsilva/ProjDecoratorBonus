package br.com.modelo;

import br.com.generico.Bonus;

public class Bonus5Gbinternet extends Bonus{

	public Bonus5Gbinternet(String descricao, double preco) {
		super(descricao, preco);
		// TODO Auto-generated constructor stub
	}

}
